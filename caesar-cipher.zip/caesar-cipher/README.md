#  Caesar Cipher CLI Tool (Python)

A simple command-line tool written in Python that implements the **Caesar cipher** for encrypting and decrypting messages.

##  Requirements

- Python 3.x
- No external dependencies (uses only standard library)

##  Overview

This project demonstrates a basic encryption algorithm where each letter in a message is shifted by a randomly generated key.

It is designed for:

* Learning cryptography fundamentals
* Practicing Python programming
* Understanding basic security concepts



##  Features

*  Encrypt messages using a random key
*  Decrypt messages using a user-provided key
*  Secure access to encryption key (password protected)
*  Interactive CLI menu
*  Auto-exit after multiple failed password attempts



##  How It Works

The Caesar cipher shifts each letter of the alphabet by a fixed number:

Example with key = 3:

```
A → D
B → E
Z → C
```

* Uppercase and lowercase letters are handled separately
* Non-alphabetic characters remain unchanged



##  Getting Started

### 1. Clone the repository

https://github.com/prototypeX-sys/josaphat.github.io

```bash
git clone https://github.com//caesar-cipher.git
cd caesar-cipher
```

### 2. Run the program

```bash
python script.py
```



##  Usage

Once the program starts, you’ll see a menu:

```
1. Encrypt a message
2. Decrypt a message
3. Access encryption key
4. Exit
```

### Encrypt

* Enter your message
* The program generates a random key automatically

### Decrypt

* Enter the encrypted message
* Provide the key used during encryption

###  Access Key

* Password required: `159753`
* Maximum 3 attempts


##  Project Structure

```
caesar-cipher/
│── script.py
│── README.md
│── .gitignore

```



## 👨‍💻 Author 

Josaphat Sanogo
