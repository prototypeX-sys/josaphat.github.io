
#Chiffrement César en Python

import string
import random
import time
import sys

# Liste des lettres majuscules et minuscules
up = list(string.ascii_uppercase)
low = list(string.ascii_lowercase)

# Variable globale pour stocker la clé
rand = 0

def cle_random():
    """
    Génère une clé aléatoire entre 1 et 25 (modulo 26)
    en évitant les multiples de 26 (qui ne changeraient rien)
    """
    global rand
    rand = random.randint(1, 1000)
    
    # On évite les valeurs multiples de 26
    while rand % 26 == 0:
        rand = random.randint(1, 1000)
    
    # Réduction dans l'intervalle [0, 25]
    rand = rand % 26


def cle_de_crypt():
    """
    Permet d'afficher la clé de cryptage
    avec un mot de passe (3 tentatives max)
    """
    code = "159753"
    i = 1

    while i <= 3:
        c = input("Entrez le mot de passe pour accéder à la clée de cryptage: ")

        if c == code:
            print(f"\nCLE DE CRYPTAGE: [ {rand} ]\n")
            break

        elif i == 3:
            print("Arrêt du programme dans 5 secondes ☠️\n")
            for x in range(5, 0, -1):
                print(f"{x}\r", end="")
                time.sleep(1)
            sys.exit("\nFIN\n")

        else:
            print(f"Tentative {i} ratée, il vous reste encore {3-i} essais")
            i += 1


def crypt(text):
    """
    Crypte un texte avec un décalage (chiffrement de César)
    """
    cle_random()  # Génère une nouvelle clé
    out = []

    for letter in text:
        if letter in up:
            # Décalage pour majuscules
            out.append(up[(up.index(letter) + rand) % 26])

        elif letter in low:
            # Décalage pour minuscules
            out.append(low[(low.index(letter) + rand) % 26])

        else:
            # On garde les caractères spéciaux inchangés
            out.append(letter)

    return "".join(out)


def decrypt(n, text):
    """
    Décrypte un texte en utilisant la clé fournie
    """
    out = []

    for letter in text:
        if letter in up:
            out.append(up[(up.index(letter) - n) % 26])

        elif letter in low:
            out.append(low[(low.index(letter) - n) % 26])

        else:
            out.append(letter)

    return "".join(out)


# PROGRAMME PRINCIPAL 

print("")
MENU = """Faites un choix en entrant le chiffre correspondant:
1. Crypter un message
2. Décrypter un message
3. Accéder à la clé de cryptage
4. Quitter
"""
print(MENU)

choix = input("Entrez votre choix: ")

while True:
    match choix:

        case "1":
            print("Entrez le message à crypter ici👇")
            text_c = input("MESSAGE: ")
            print(f"\nMessage crypté: {crypt(text_c)}")

        case "2":
            print("Entrez le message à décrypter et la clé ici👇")
            text_d = input("MESSAGE: ")

            try:
                clee = int(input("CLE: "))
                print(f"\nMESSAGE DECRYPTE: {decrypt(clee, text_d)}")
            except ValueError:
                print("Clé invalide (doit être un nombre)")

        case "3":
            cle_de_crypt()

        case _:
            print("Arrêt du programme dans 5 secondes ☠️\n")
            for x in range(5, 0, -1):
                time.sleep(1)
                print(f"  {x}  \r", end=" ")
            print("")
            sys.exit("\nFIN\n")

    print("")
    print(MENU)
    choix = input("Entrez votre choix: ")