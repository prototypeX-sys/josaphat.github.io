# Student Grade Manager

A simple Python program to manage students and their grades.

## Features

- Add students and their grades
- Calculate student averages
- Display all students
- Show ranking based on averages

## Subjects

The program uses the following subjects:

- Mathematics
- French
- English
- Physics & Chemistry
- Biology
- History & Geography
- Physical Activities

## How it works

The program displays a menu with different options:

1. Add a student
2. Show all students
3. Show ranking
4. Clear lists
5. Exit

When adding a student, the user must enter grades between **0 and 20** for each subject.  
The program then calculates the average and determines if the student **passed or failed**.

## Requirements

Python 3.x

## How to Run

Clone the repository and run:

python main.py

## Author

Josaphat Sanogo

## Purpose

Educational project created to improve Python skills, algorithms, and problem-solving abilities.