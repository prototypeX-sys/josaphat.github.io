
# Student Grade Manager
# This program allows the user to:
# - Add student grades
# - Display students
# - Display class ranking
# Author: Josaphat

import time,sys
print()
print("Welcome to this Students Grade Manager")
print()

# List of subjects
tables=["mathematics","french","english","Physics_Chimistry","Biology","History_geography","Physical_activities"]

# List to store notes
notes=[]

# List to store students information
student=[]

# List used for ranking
student2=[]

# Principal menu
def Menu():
    print("""
     * * * * MENU * * * * 
     *                  *    
     *  1-Add student   *
     *  2-Show students *
     *  3-Show ranking  *
     *  4-Clear lists   *
     *  5-Exit          *
     *                  *
     *  * * * * * * * * * 
           """)
    
# Function to insert a new student,mark and calculate average

def adding():
    resp=1

# Loop to allow adding multiple students
    while resp==1:
        print()
        names=input("Insert student name: ")
        sum_notes=0
        
# Loop through all subjects to collect notes
        for i in tables:
            while True:
                try:
                    print()
                    note=float(input(f"Insert {i} note: "))
                
# Check if the note is between 0 and 20
                    if note>20 or note<0:
                        print()
                        print("Insert a valid note(0-20)")
                    else:
                        sum_notes+=note
                        notes.append({names,note}) 
                        break      
                except ValueError:
                    print()
                    print("Insert a number")


# Calculate the student average    
        average=sum_notes/len(tables)

# Check if the student passed or failed
        if average>=10:
            status="Pass"
        else:
            status="Fail"
        print()
        prints="\n"+"Nom:"+names+"\n"+"Average:"+str(round(average,2))+"\n"+"Statuts:"+status+"\n"
        prints2=names+":"+str(round(average,2))
        student.append(prints)
        student2.append(prints2)
        resp=int(input("Do you want to insert other students grade?(1-YES,2-NO): "))
             
# Function to display students           
def showS():
    print()
    print("Students list")
    print(*student)

# Function to obtain the avarage  
def av_get(x):
    return float(x.split(":")[1])   

# Function to clear lists
def clearing():
    notes.clear()
    student.clear()
    student2.clear()
    print("The lists have been successfully cleared.")

# Function to display ranking 
def showR():
    print()
    print("Class ranking")
    print()
    rang=sorted(student2,key=av_get,reverse=True)
    for i in enumerate(rang,start=1):
        print(*i)

# Function to end program
def exit_SGM():
    print()
    print(f"Program ends in 5 seconds\n")
    for x in range(5,-1,-1):
        time.sleep(1)
        print(f"{x}\r",end=" ",flush=False)
        time.sleep(0.5)   
    sys.exit() 

# Main program loop    
while True:
    Menu()
    print()
    userchoice=input("Insert your choice: ")
    match userchoice:
        case "1":
            adding()
        case "2":
            showS()
        case "3":
            showR()
        case"4":
            clearing()
        case "5":
            exit_SGM()
        case _:
            print()
            print("Invalid choice")
            